const express = require('express');
const app=express();
const router=require('./routes/user');
const mongosse=require('mongoose');
const cors=require('cors');

mongosse.connect("mongodb+srv://test:1234@cluster0.d7sey.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0",{

}).then(()=>{console.log("database is connected")}).catch((err)=>console.log("not connected"))

app.use(cors())
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(router);

const port=4000;


app.listen(port,()=>console.log(`i am working on port ${port}`))
