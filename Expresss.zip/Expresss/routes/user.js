const express=require("express");
const router=express.Router();
const User=require("../schema/user");


router.get('/',async (req,res)=>{
    
    const data=await User.find();
    res.json(data);
})

router.post('/',  (req, res) => {
          console.log(req)
        const data = req.body;

        console.log(data,"datatatatatat");
        
        const newUser = new User(data);
        newUser.save(); // Await for database save

        res.status(201).json("User register"); // Return saved user
   
});


router.put('/', async (req, res) => {
    try {
        const { userName, email, phoneNumber } = req.body;

       

        const updatedUsers = await User.updateOne(
            { userName: userName },  // Ensure this matches existing users
            { $set: { email: email, phoneNumber: phoneNumber } }
        );

        if (updatedUsers.modifiedCount === 0) {
            return res.status(404).json({ error: "No users updated, check userName" });
        }

        res.json(updatedUsers);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});
router.delete('/',(req,res)=>{
    
    res.json("data is deleted");
})

module.exports=router;